package com.example.dimi.fridgepay

import android.app.Application
import com.example.dimi.fridgepay.utils.ComponentManager

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ComponentManager.initComponents(this)
    }
}