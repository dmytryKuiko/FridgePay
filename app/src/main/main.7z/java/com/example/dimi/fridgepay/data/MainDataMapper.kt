package com.example.dimi.fridgepay.data

import javax.inject.Inject

class MainDataMapper
@Inject constructor() {
}