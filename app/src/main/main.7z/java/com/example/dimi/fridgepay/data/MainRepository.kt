package com.example.dimi.fridgepay.data

interface MainRepository {
}