package com.example.dimi.fridgepay.data

import javax.inject.Inject

class MainRepositoryImpl
@Inject constructor(private val store: MainStore,
                    private val serviceApi: ServiceProductsApi,
                    private val mapper: MainDataMapper) : MainRepository {
}