package com.example.dimi.fridgepay.data

interface MainStore {
}