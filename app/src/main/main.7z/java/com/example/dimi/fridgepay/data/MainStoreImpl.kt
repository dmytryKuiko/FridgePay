package com.example.dimi.fridgepay.data

import com.example.dimi.fridgepay.data.db.ProductDao
import javax.inject.Inject

class MainStoreImpl
@Inject constructor(private val productDao: ProductDao) : MainStore{
}