package com.example.dimi.fridgepay.data

import com.example.dimi.fridgepay.di.modules.ProductsResponse
import io.reactivex.Single
import retrofit2.http.GET

interface ServiceProductsApi {
    @GET
    fun getAllProducts(): Single<ProductsResponse>
}