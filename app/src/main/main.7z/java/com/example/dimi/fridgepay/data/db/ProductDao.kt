package com.example.dimi.fridgepay.data.db

import android.arch.persistence.room.Dao
import com.example.dimi.fridgepay.model.Product

@Dao
abstract class ProductDao : BaseDao<Product> {
}