package com.example.dimi.fridgepay.data.db

object TableNames {
    const val TABLE_PRODUCT = "TABLE_PRODUT"
}