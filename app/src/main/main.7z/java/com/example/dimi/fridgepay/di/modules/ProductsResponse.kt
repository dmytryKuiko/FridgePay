package com.example.dimi.fridgepay.di.modules

class ProductsResponse {
}