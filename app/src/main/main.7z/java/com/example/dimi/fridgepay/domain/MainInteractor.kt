package com.example.dimi.fridgepay.domain

import com.example.dimi.fridgepay.model.ProductDisplayable
import com.example.dimi.fridgepay.model.ProductsParsed
import io.reactivex.Flowable
import io.reactivex.Single

interface MainInteractor {

    fun refreshProducts(): Single<ProductsParsed>

    fun getSavedProducts(): Flowable<ProductDisplayable>

    fun productAdded(productDisplayable: ProductDisplayable)

    fun productRemoved(productDisplayable: ProductDisplayable)

}