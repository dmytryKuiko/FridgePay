package com.example.dimi.fridgepay.domain

import com.example.dimi.fridgepay.data.MainRepository
import com.example.dimi.fridgepay.model.ProductDisplayable
import com.example.dimi.fridgepay.model.ProductsParsed
import io.reactivex.Flowable
import io.reactivex.Single
import javax.inject.Inject

class MainInteractorImpl
@Inject constructor(private val repository: MainRepository) : MainInteractor {
    override fun refreshProducts(): Single<ProductsParsed> {
        return Single.just(ProductsParsed(1, "", "", "", "", "", emptyList()))
    }

    override fun getSavedProducts(): Flowable<ProductDisplayable> {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun productAdded(productDisplayable: ProductDisplayable) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun productRemoved(productDisplayable: ProductDisplayable) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}