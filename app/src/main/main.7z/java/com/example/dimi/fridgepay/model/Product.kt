package com.example.dimi.fridgepay.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.example.dimi.fridgepay.data.db.TableNames

@Entity(tableName = TableNames.TABLE_PRODUCT)
data class Product(
    val type: String,

    val name: String,

    @ColumnInfo(name = "content_volume")
    val contentVolume: Int,

    val price: Double,

    @ColumnInfo(name = "image_name")
    val imageName: String,

    @ColumnInfo(name = "bought_count")
    val boughtCount: Int,

    @PrimaryKey(autoGenerate = true)
    val id: Int? = null
)