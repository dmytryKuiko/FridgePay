package com.example.dimi.fridgepay.model

sealed class ProductDisplayable {
    class Product(
        val image: String,
        val name: String,
        val price: Double
    ) : ProductDisplayable()

    object AllData : ProductDisplayable()
}