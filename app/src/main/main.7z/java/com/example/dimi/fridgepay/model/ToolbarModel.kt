package com.example.dimi.fridgepay.model

class ToolbarModel(val backVisibility: Int,
                   val basketVisibility: Int)