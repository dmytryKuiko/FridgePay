package com.example.dimi.fridgepay.presentation.presenter

interface ActivityPresenter {
    fun startNavigation()
}