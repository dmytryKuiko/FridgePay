package com.example.dimi.fridgepay.presentation.presenter

import com.example.dimi.fridgepay.presentation.BasePresenter
import com.example.dimi.fridgepay.presentation.ToolbarPresenter

interface BasketPresenter : ToolbarPresenter {
    fun backClicked()
}