package com.example.dimi.fridgepay.presentation.presenter

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.view.View
import com.example.dimi.fridgepay.domain.MainDomainMapper
import com.example.dimi.fridgepay.domain.MainInteractor
import com.example.dimi.fridgepay.model.ProductDisplayable
import com.example.dimi.fridgepay.model.ToolbarModel
import com.example.dimi.fridgepay.utils.ScreenKeys
import ru.terrakok.cicerone.Router
import javax.inject.Inject

class MainPresenterImpl
@Inject constructor(
    private val interactor: MainInteractor,
    private val mapper: MainDomainMapper,
    private val router: Router
) : MainPresenter {

    private val toolbarLiveData: MutableLiveData<ToolbarModel> = MutableLiveData()

    init {
        toolbarLiveData.value = ToolbarModel(backVisibility = View.INVISIBLE, basketVisibility = View.VISIBLE)
        interactor.refreshProducts()
            .map(mapper)
    }

    override fun getData(): LiveData<ProductDisplayable> {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun disposeDisposables() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun getToolbarData(): LiveData<ToolbarModel> = toolbarLiveData

    override fun basketClicked() {
        router.navigateTo(ScreenKeys.BASKET_SCREEN)
    }

    override fun productClicked(product: ProductDisplayable) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun productLongClicked(product: ProductDisplayable) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun swipeRefreshed() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onBackPressed() {
        router.finishChain()
    }
}