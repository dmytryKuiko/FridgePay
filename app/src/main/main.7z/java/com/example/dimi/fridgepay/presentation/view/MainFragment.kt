package com.example.dimi.fridgepay.presentation.view


import android.arch.lifecycle.Observer
import android.content.Context
import android.os.Bundle
import android.widget.ImageButton

import com.example.dimi.fridgepay.R
import com.example.dimi.fridgepay.presentation.BaseFragment
import com.example.dimi.fridgepay.presentation.presenter.MainPresenter
import com.example.dimi.fridgepay.utils.ComponentManager
import kotlinx.android.synthetic.main.fragment_main.*
import kotlinx.android.synthetic.main.toolbar.*
import javax.inject.Inject

class MainFragment : BaseFragment() {

    @Inject
    lateinit var presenter: MainPresenter

    override val layoutId: Int
        get() = R.layout.fragment_main

    override fun injectModule(context: Context) {
        ComponentManager.getMainComponent().inject(this)
    }

    override fun onBackPressed() {
        presenter.onBackPressed()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        presenter.getToolbarData().observe(this, Observer {
            it?.let {
                toolbar_basket_button.visibility = it.basketVisibility
                toolbar_back_button.visibility = it.backVisibility
            }
        })
        toolbar_basket_button.setOnClickListener { presenter.basketClicked() }
    }
}
