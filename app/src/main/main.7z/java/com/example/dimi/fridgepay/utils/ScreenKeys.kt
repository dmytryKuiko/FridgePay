package com.example.dimi.fridgepay.utils

object ScreenKeys {
    const val MAIN_SCREEN = "MAIN_SCREEN"
    const val BASKET_SCREEN = "BASKET_SCREEN"
}